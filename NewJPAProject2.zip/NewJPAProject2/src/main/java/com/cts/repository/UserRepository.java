package com.cts.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	
	@Query("select u from User u where u.uName=(:uName) and u.password=(:password)")
	User findByLoginData(String uName, String password);
	
	@Query("select u from User u where u.uName=(:uName)")
	User findByuName(String uName);

}

