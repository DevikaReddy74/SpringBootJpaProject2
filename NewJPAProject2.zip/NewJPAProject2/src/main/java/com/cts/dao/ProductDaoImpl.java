package com.cts.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.repository.ProductRepository;
import com.cts.model.Product;
import com.cts.model.User;

@Service
public class ProductDaoImpl implements ProductDao {

	@Autowired
	ProductRepository ProductRepository;
	
	@Override
	public void addPro(Product pro) {
		// TODO Auto-generated method stub
		ProductRepository.save(pro);
	}

	@Override
	public List<Product> getAllPro() {
		
		List<Product> proList =  ProductRepository.findAll();
		return proList;
	}

	@Override
	public Product getProById(int id) {
		// TODO Auto-generated method stub
		Product pro = ProductRepository.getById(id);
		return pro;
	}

	@Override
	public void updatePro(Product pro) {
		// TODO Auto-generated method stub
		ProductRepository.save(pro);

	}

	@Override
	public void deletePro(int proId) {
		// TODO Auto-generated method stub
		ProductRepository.deleteById(proId);
	}

	/*@Override
	public Product validatePro(Product pro) {
		// TODO Auto-generated method stub
		Product pro1 = ProductRepository.findByLoginData(pro.getuName(), pro.getPassword());
		return pro;
	}*/

}

