package com.cts.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.model.Product;

@Service
public interface ProductDao {

	public void addPro(Product pro);
	public List<Product> getAllPro();
	public Product getProById(int id);
	public void updatePro(Product pro);
	public void deletePro(int proId);
	//public Product validatePro(Product pro);
}
