package com.cts.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cts.dao.ProductDao;
import com.cts.dao.UserDao;
import com.cts.model.Product;
import com.cts.model.User;

@Controller
public class ProductController {

	@Autowired
	Product pro;

	@Autowired
	ProductDao productDao;

	String msg;

	@RequestMapping("addPro")
	public String showAddProductForm(Model model) {
		model.addAttribute("pro", pro);
		// model.addAttribute("msg", msg);
		return "addProduct";
	}

	@RequestMapping("submitpro")
	public ModelAndView saveUser(@ModelAttribute("pro") Product pro, ModelAndView mv,
			@RequestParam("pic") MultipartFile file) throws IOException {

		System.out.println("In Save User");
		byte[] proPic = file.getBytes();

		pro.setProPic(proPic);
		productDao.addPro(pro);
		mv.addObject("msg", "Product Added Successfully");
		// mv.addObject("user", user);
		mv.setViewName("addProduct");
		return mv;
	}

	@RequestMapping("getallpro")
	public ModelAndView getAllPro(ModelAndView mv, HttpSession session) {

		String sess = (String) session.getAttribute("admin");
		if (sess != null) {
			List<Product> proList = productDao.getAllPro();
			mv.addObject("pros", proList);
			mv.addObject("msg", msg);
			mv.setViewName("viewpros");
			return mv;
		} else {
			msg = "Session Closed. Login Again";
			mv.addObject("msg", msg);
			mv.setViewName("redirect:/");
			return mv;
		}

	}
	
	@RequestMapping("usergetallpro")
	public ModelAndView getAllUserPros(ModelAndView mv, HttpSession session) {

		String sess = (String) session.getAttribute("access");
		if (sess != null) {
			List<Product> proList = productDao.getAllPro();
			mv.addObject("pros", proList);
			mv.addObject("msg", msg);
			mv.setViewName("userviewpros");
			return mv;
		} else {
			msg = "Session Closed. Login Again";
			mv.addObject("msg", msg);
			mv.setViewName("redirect:/home");
			return mv;
		}

	}
	

	@RequestMapping("getbyproid/{id}")
	public ModelAndView getById(@PathVariable int id, ModelAndView mv, HttpServletRequest request) {

		HttpSession session = request.getSession();
		String sess = (String) session.getAttribute("admin");
		if (sess != null) {
			Product pro = productDao.getProById(id);
			mv.addObject("pro", pro);
			mv.setViewName("showpro");
			return mv;
		} else {
			mv.setViewName("redirect:/");
			return mv;
		}

	}
	
	@RequestMapping("usergetbyproid/{id}")
	public ModelAndView usergetById(@PathVariable int id, ModelAndView mv, HttpServletRequest request) {

		HttpSession session = request.getSession();
		String sess = (String) session.getAttribute("access");
		if (sess != null) {
			Product pro = productDao.getProById(id);
			mv.addObject("pro", pro);
			mv.setViewName("usershowpro");
			return mv;
		} else {
			mv.setViewName("redirect:/home");
			return mv;
		}

	}

	@RequestMapping("updatepro/{id}")
	public String getUpdateUser(@PathVariable int id, Model m, HttpSession session) {

		String sess = (String) session.getAttribute("admin");
		if (sess != null) {
			Product pro = productDao.getProById(id);
			System.out.println("In Controller : " + pro);
			m.addAttribute("pro", pro);
			return "updatepro";
		} else {
			return "redirect:/";
		}

	}

	/*
	 * @RequestMapping("saveupdate") public String
	 * saveUpdate(@ModelAttribute("user") User user) { userDao.updateUser(user);
	 * return "redirect:/getall";
	 * 
	 * }
	 */

	@RequestMapping("saveupdatepro")
	public ModelAndView saveUpdate(@ModelAttribute("pro") Product pro, ModelAndView mv,
			@RequestParam("pic") MultipartFile file) throws IOException {

		System.out.println("In Save User");
		byte[] proPic = file.getBytes();

		pro.setProPic(proPic);
		productDao.addPro(pro);
		mv.addObject("msg", "Product Updated Successfully");
		// mv.addObject("user", user);
		mv.setViewName("redirect:/getallpro");
		return mv;
	}

	@RequestMapping("deletepro/{id}")
	public String deleteUser(@PathVariable int id, HttpSession session) {

		String sess = (String) session.getAttribute("admin");
		if (sess != null) {
			productDao.deletePro(id);
			return "redirect:/getallpro";
		} else {
			return "redirect:/";
		}

	}

	@RequestMapping("alogout")
	public String destroySession(HttpServletRequest request) {
		request.getSession().invalidate();
		return "redirect:/";
	}

}
