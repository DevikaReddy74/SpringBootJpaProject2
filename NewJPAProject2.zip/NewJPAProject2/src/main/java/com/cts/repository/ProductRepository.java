package com.cts.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Product;
import com.cts.model.User;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{
	
	@Query("select u from User u where u.uName=(:uName) and u.password=(:password)")
	User findByLoginData(String uName, String password);

}

