package com.cts.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AdminController {
	
	String msg;
	@RequestMapping("/")
	public String start(Model model) {
		model.addAttribute("msg", msg);
		return "adminLogin";
	}

	@RequestMapping("/aValidate")
  public String submit(@ModelAttribute("admin") Admin admin,Model mv,  HttpSession session) {
		if (admin != null && admin.getaUName() != null & admin.getaPassword() != null) {
			if (admin.getaUName().equals("admin") && admin.getaPassword().equals("admin123")) {
				// msg = "";
				session.setAttribute("admin", admin.getaUName());
				return "redirect:/getallpro";
			} else {
				msg="Invalid Details";
				return "redirect:/";
			}
		} else {
			msg="Please enter Details";
			return "redirect:/";
		}
	}
}
