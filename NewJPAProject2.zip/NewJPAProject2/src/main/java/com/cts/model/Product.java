package com.cts.model;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;


@Entity
@Table(name = "product")
@Component
public class Product {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	private String proName;
	private Double price;
	private String proDescri;
	private String[] size;
	@Lob
	private byte[] proPic;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Product(Integer id, String proName, Double price, String proDescri, String[] size) {
		super();
		this.id = id;
		this.proName = proName;
		this.price = price;
		this.proDescri = proDescri;
		this.size = size;
	}

	public Product(Integer id, String proName, Double price, String proDescri, String[] size, byte[] proPic) {
		super();
		this.id = id;
		this.proName = proName;
		this.price = price;
		this.proDescri = proDescri;
		this.size = size;
		this.proPic = proPic;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProName() {
		return proName;
	}
	
	public void setProName(String proName) {
		this.proName = proName;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getProDescri() {
		return proDescri;
	}

	public void setProDescri(String proDescri) {
		this.proDescri = proDescri;
	}

	public String[] getSize() {
		return size;
	}

	public void setSize(String[] size) {
		this.size = size;
	}

	public byte[] getProPic() {
		return proPic;
	}

	public void setProPic(byte[] proPic) {
		this.proPic = proPic;
	}

	public String getProPicture() {
		return Base64.encodeBase64String(proPic);
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", proName=" + proName + ", price=" + price + ", proDescri=" + proDescri
				+ ", size=" + Arrays.toString(size) + "]";
	}
	
}
