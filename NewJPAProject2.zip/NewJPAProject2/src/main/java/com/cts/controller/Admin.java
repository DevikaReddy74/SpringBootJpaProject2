package com.cts.controller;

public class Admin {
	private String aUName;
	private String aPassword;
	
	public String getaUName() {
		return aUName;
	}
	public void setaUName(String aUName) {
		this.aUName = aUName;
	}
	public String getaPassword() {
		return aPassword;
	}
	public void setaPassword(String aPassword) {
		this.aPassword = aPassword;
	}
	
}
